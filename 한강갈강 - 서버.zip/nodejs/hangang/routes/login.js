const express = require('express');
const router = express.Router();
const async = require('async');
const bcrypt = require('bcrypt-node');
const pool = require('../config/db_pool');
const crypto = require('crypto');

router.get('/', function(req,res){

});

router.post('/login', function(req, res) {
  pool.getConnection(function(error, connection){
    if(error)//커넥션 오류
    {
      console.log("getConnection Error" + error);
      res.status(503).send({"message":1});
    }
    else{
      // id랑 password를 입력하지 않았을 때
      if(!(req.body.id&&req.body.password)) res.status(400).send({"message":2});
      else{
        connection.query('select * from user where id = ?', req.body.id, function(error, result) {
          if(error) {
            console.log("selecting error" + error);
            res.status(503).send({"message":3});
          }
          else {
            //테이블에 없는 아이디로 레코드 조회
            if(result.length==0) res.status(400).send({"message":4});
            else {
              console.log(result[0].password);
              // console.log( bcrypt.hashSync(req.body.password));
              // console.log( bcrypt.hashSync(req.body.password));
              // console.log( bcrypt.hashSync(req.body.password));
              // console.log( bcrypt.hashSync(req.body.password));

              let pw_correct = crypto.createHash('sha256').update(req.body.password).digest('base64') === result[0].password;;
              console.log(req.body.password);


              console.log(pw_correct);


              if(pw_correct){
                console.log('로그인 성공');

                req.session.user = result[0];

                res.status(200).send({"message":5});

              }

              else
              {
              res.status(400).send({"message":6}); //비밀번호 오류
              console.log(result);
              console.log(result[0].password);
              console.log(req.body.password);
              console.log('비밀번호 틀림');
              }
            }
          }
        });
      }
    }
  });
});
// router.post('/login', async (req, res) => {
//   try {
//
//     if(!(req.body.id&&req.body.password)) res.status(400).json({message : '1'}); //email과 password를 모두 입력하세요
//     else {
//       //let hashed = bcrypt.hashSync(req.body.password, saltRounds); //비밀번호를 해싱합니다.
//       //console.log(hashed);
//       var connection = await pool.getConnection();
//       //let query = 'select password, user_id from user where email = ?'; //트레이너의 id와 비밀번호를 가져옵니다.
//       let query = 'select * from user where id = ?';
//       let result = await connection.query(query, req.body.id);
//
//       //var push_token = req.body.push_token;
//
//       if(result.length==0) //trainer테이블에 없는 이메일로 레코드를 조회한다면 쿼리의 결과는 0이 됩니다.
//
//         res.status(400).send({message : '2'}); //존재하지 않는 계정일 경우
//
//       else { //이메일이 테이블에 존재하면( 회원가입된 이메일이라면 )
//         console.log(result[0].password);
//         console.log( bcrypt.hashSync(req.body.password));
//         console.log( bcrypt.hashSync(req.body.password));
//         console.log( bcrypt.hashSync(req.body.password));
//         console.log( bcrypt.hashSync(req.body.password));
//         let pw_correct = crypto.createHash('sha256').update(req.body.password).digest('base64') === result[0].password; //비밀번호가 맞는지 비교합니다.
//         //let pw_correct = bcrypt.compare(req.body.password, result[0].password);
//         console.log(pw_correct);
//         //console.log(req.body.password);
//         if(pw_correct){
//         console.log('로그인 성공');
//
//         res.status(200).json({result : result[0], message : '3'}); //로그인 성공
//         //
//         // }
//         //res.redirect('/tag/'+result[0].user_id);
//         }
//         else res.status(400).send({message : '4'}); //비밀번호 오류
//
//       }
//     }
//   }
//   catch(err) {
//     console.log(err);
//     res.status(500).send({message : '5' + err}); //커넥션 에러
//   }
//   finally {
//     pool.releaseConnection(connection);
//   }
//
// });

module.exports = router;
