const express = require('express');
const aws = require('aws-sdk');
const router = express.Router();
const async = require('async');
//aws.config.loadFromPath('./config/aws_config.json');
const pool = require('../config/db_pool');
const bcrypt = require('bcrypt-node');
const crypto = require('crypto');
//const saltRounds = bcrypt.genSaltSync(10);

router.post('/dup', function(req, res) {//아이디 중복확인
  var id = req.body.id;
  pool.getConnection(function(error, connection){
    if(error)
    {
      console.log("getConnection Error" + error);
      res.status(503).send('1');
    }
    else
    {
      connection.query('select id from user where id = ?;', [id], function(error, result) {
        if(error) {
          console.log("selecting Error" + error);
          res.status(503).send('2');
        }

        else {
          if(result.length == 0){
            //console.log(result);
                console.log('회원가입 가능 아이디');
                res.status(200).send('3');
              }
              else{

                res.status(200).send('4');
              }
              connection.release();
        }
      });
    }
  });
});


// router.post('/up', async function(req, res){
//   try {
//
// var id = req.body.id;
// var phoneNum = req.body.phoneNum;
// var password = req.body.password;
// var username = req.body.username;
//
//     if (!(id&&phoneNum&&password&&username)) res.status(503).json({message : '1'}); //회원정보를 모두 기입하세요
//     else {
//
//       let hashed = crypto.createHash('sha256').update(req.body.password).digest('base64');
//
//       //bcrypt.hashSync(req.body.password); //비밀번호를 해싱합니다.
//        let record = {
//          'id': req.body.id,
//          'phoneNum': req.body.phoneNum,
//          'password': hashed,
//          'username':req.body.username
//        };
//       var connection = await pool.getConnection();
//       let query = 'insert into user set ?'
//       let signup = await connection.query(query, record);
//        var last = signup.insertId;
//       let query2 = 'select * from user where user_id = '+last;
//       let signup_result = await connection.query(query2, last);
//
//       req.session.user = signup_result[0];
//
//       res.status(200).json({user : signup_result[0], message : '2'}); //가입 성공
//     }
//   }
//   catch(err) {
//     console.log(err);
//     res.status(503).json({message : '3'}); //connection error
//   }
//   finally {
//     pool.releaseConnection(connection);
//   }
// });
//





























router.post('/up', function(req,res){
  var id = req.body.id;
  var password = req.body.password;
  var phoneNum = req.body.phoneNum;
  var username = req.body.username;

  pool.getConnection(function(error, connection){
    if(error)
    {
      console.log("getConnection Error" + error);
      res.status(503).send({"message":1});
      //connection.release();
    }
    else{
      if(!(id&&password&&phoneNum&&username)) res.status(503).send({"message":2});
      else {
        let hashed = crypto.createHash('sha256').update(req.body.password).digest('base64');
        console.log(hashed);
        let record = {
          'id': req.body.id,
          'phoneNum': req.body.phoneNum,
          'password': hashed,
          'username': req.body.username
        };

        let query = 'insert into user set ?';

      var signup =  connection.query(query, record, function(error, result){
          //var last = result.insertId;

          if(error) {
            console.log("insert" + error); res.status(203).send({"message":3});
            connection.release();
          }
          else{
            console.log('회원가입 성공');
            var last = signup.insertId;
            let query2 = 'select * from user where user_id = '+last;


            let signup_result = connection.query(query2, last, function(error, result2){
            req.session.user = signup_result[0];
             res.status(200).send({"message":4});
              connection.release();
          });
          }
        });

      }
    }

  });

});


module.exports = router;
