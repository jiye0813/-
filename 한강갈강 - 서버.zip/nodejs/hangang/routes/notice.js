const express = require('express');
const router = express.Router();
const pool = require('../config/db_pool');
const async = require('async');

router.get('/', function(req, res) {
  console.log('공지사항');
  pool.getConnection(function(error, connection) {
    if(error) {
      console.log('getConnection error' + error);
      res.status(500).send({"message":1});
    }
    else {
      connection.query('select * from notice order by notice_date desc', function(error, result) {
        if(error) {
          console.log('select error' + error);
          res.status(503).send({"message":2});
        }
        else{
          console.log('공지사항 조회 성공');
          res.status(200).send({"result": result, "message":3});
        }
      });
    };
  })
})

router.post('/notice', function(req, res) {
  var user_type = req.session.user.user_type;

  if(req.session.user.user_type!=2){
    console.log();
    res.status(503),send({message : '4'});
    return;
  }
  else {
    let notice = {
      //'user_id' : req.session.user.user_id,
      'title' : req.body.title,
      'content' : req.body.content,
      'notice_date' : req.body.notice_date,
      'writer' : req.body.writer
    };

    pool.getConnection(function(error, connection) {
      if(error) {
        console.log("getConnection " +error);
        res.status.send('1');
      }
      else{
        connection.query('insert into notice set ? ', [notice], function(error, result){
          if(error) {
            console.log("공지사항 작성 실패 " +error);
            res.status.send('2');
          }
          else {
            console.log('작성 완료');
            var last = result.insertId;
            res.status(200).json({result: notice, message : '3'});
          }
        });
      }

    });
  }
  console.log('공지사항 작성');


});

module.exports = router;
