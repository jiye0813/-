const express = require('express');
const router = express.Router();
const pool = require('../config/db_pool');
const async = require('async');

router.get('/', function(req, res) {
  console.log('예약창');

  var user_id = req.session.user.user_id;

  pool.getConnection(function(error, connection) {
    if(error) {
      console.log('getConnection error' + error);
      res.status(500).send({"message":1});
    }
    else {
      connection.query('select * from book where user_id = ? and total_rate is not null order by date desc', user_id, function(error, result) {
        if(error) {
          console.log('select error' + error);
          res.status(503).send({"message":2});
        }
        else {
          console.log('예약 조회 성공');
          res.status(200).send({result, "message" : 3});
        }
      });
    }
  });
});

module.exports = router;
