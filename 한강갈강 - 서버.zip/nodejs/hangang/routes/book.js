﻿
const express = require('express');
const router = express.Router();
const dateformat = require('moment');
const pool = require('../config/db_pool');
const async = require('async');
const moment = require('moment');

router.get('/:facility_id', function(req, res) {
  console.log('예약창');

  pool.getConnection(function(error, connection) {
    if(error) {
      console.log('getConnection error' + error);
      res.status(500).send({"message":1});
    }
    else {
      connection.query('select river_name from river where facility_id = ? ', [req.params.facility_id], function(error, result) {
        if(error) {
          console.log('select error' + error);
          res.status(503).send({"message":2});
        }
        else {
          console.log('한강 이름 조회 성공');
          res.status(200).send({result, message : '3'});
        }
      });
    }
  });
});




router.post('/book', function(req, res){


    //var user_id = req.session.user.user_id;
    var river = req.body.river;
    var facility = req.body.facility;
    var date = req.body.date;
    var adult = req.body.adult;
    var baby = req.body.baby;

    //var phoneNum;
    //let phoneNum = 'select phoneNum from user where user_id = ?'
    //console.log(user_id);


    pool.getConnection(function(error, connection){
      if(error) {
        console.log("getConnection error" + error);
        res.status(503).send({"message":1});
      }
      else {
        connection.query('select user_id from user where id = ?' , [req.body.id], function(error, id_result){
          if(error) {
            console.log('select user_id ' + error);
            res.status(503).send({"message":13});
          }
          else{
            console.log(req.body.id);
            console.log(id_result);
            var user_id = id_result[0].user_id;
          if(!facility) res.status(503).send({"message":2}); // 장소 미선택 -> 안드에서 막으면 노상관
          else{
            if(!river) res.status(503).send({"message":3}); // 시설 미선택
            else {
              if(!date) res.status(503).send({"message":4}); // 날짜 미선택
              else{
                if(!(adult||baby)) res.status(503).send({"message":5}); //인원 미선택
                else {

                  console.log(user_id);
                  connection.query('select facility, date from book where user_id = ?', user_id, function(error, al_check) {
                    if(error) {
                      console.log("시설, 날짜 조회 실패", + error);
                      res.status(503).send({"message":9});                  }
                    else{
                      var check_result = 0;
                      for(var i = 0; i < al_check.length; i++){
                        console.log('여기들어옴');
                        console.log(al_check[i].facility);
                        console.log(req.body.facility);
                        console.log(al_check[i].date);
                        console.log(req.body.date);
                        if(al_check[i].facility == req.body.facility && al_check[i].date == req.body.date) {
                          //res.status(503).send('10');

                          check_result = 1;
                          break;
                        //  connection.release();
                        }
                        else {
                          continue;
                        }
                        break;
                      }
                      console.log(check_result);
                      if(check_result == 1){
                        console.log("해당 날짜, 시설에 이미 예약");
                        res.status(503).send({"message":10});
                      }
                      else{

                          connection.query('select facility from book where date = ? and river = ?', [req.body.date, req.body.river], function(error, compare) {
                            if(error) {
                              console.log("날짜에 해당하는 시설 조회 실패");
                              res.status(503).send({"message":11});
                            }
                            else {
                              console.log(date);
                              console.log("예약 확인");
                              //console.log(compare[0]);
                              console.log(compare.length);
                              if(compare.length == 10){
                                console.log("10팀 예약 완료");
                                res.status(503).send({"message":12});
                              }
                              else{
                                connection.query('select rate_adult, rate_baby from river where facility= ? and river_name= ?',[facility, river] , function(error, rate_result){
                                  if(error){
                                    console.log("요금 조회 실패" + error); res.status(503).send('6');
                                  }
                                  else{
                                    // console.log(result[0]);
                                    // phoneNum = result[0];

                                    //--------!!!!쿼리문 result의 rowdatapacket 까는 방법!!!!!----------
                                    // Object.keys(result).forEach(function(key) {
                                    //   var phoneNum = result[key];
                                    //   console.log(phoneNum.phoneNum);
                                    // });
                                    console.log([req.body.river, req.body.facility]);
                                    console.log(req.body.river);
                                    console.log(req.body.facility);
                                    console.log(facility);
                                      console.log(river)
                                      console.log(rate_result);
                                      console.log(rate_result[0]);
                                    //console.log(rate_result[0].rate_adult);

                                    var total_rate = adult *rate_result[0].rate_adult + baby * rate_result[0].rate_baby;
                                    let lecord = {
                                      'user_id' : user_id,
                                      'river' : req.body.river,
                                      'facility' : req.body.facility,
                                      //'date' : moment(date).format('YYYY/MM/DD'),
                                      'date' : req.body.date,
                                      'adult' : req.body.adult,
                                      'baby' : req.body.baby,
                                      //'phoneNum' : req.session.user.phoneNum,
                                      //'username' : req.session.user.username,
                                      'total_rate' : total_rate
                                    };

                                    connection.query('insert into book set ?', [lecord], function(error, result2) {
                                      if(error){
                                        //console.log(result);
                                          console.log("예약 추가 실패" + error); res.status(503).send({"message":7});
                                      }
                                      else{
                                        var last = result2.insertId;
                                        console.log("에약 성공");
                                        console.log(last);
                                        res.status(200).send({"message":8});
                                      }
                                    });
                                  }
                                });
                              }
                            }
                          });
                      }

                    }
                  });
                }
              }
            }
          }
        }
        });

      }
      connection.release();
    });

});


// router.post('/book', function(req, res){
// if(req.session.user!=null){
//
//     var place = req.body.place;
//     var facility = req.body.facility;
//     var date = req.body.date;
//     var adult = req.body.adult;
//     var baby = req.body.baby;
//
//     let lecord = {
//       'user_id' : req.session.user.user_id,
//       'place' : req.body.place,
//       'facility' : req.body.facility,
//       'date' : moment(date).format('YYYY/MM/DD'),
//       'adult' : req.body.adult,
//       'baby' : req.body.baby
//     };
//
//     pool.getConnection(function(error, connection){
//       if(error) {
//         console.log("getConnection error" + error);
//         res.status(503).send('1');
//       }
//       else {
//         if(!place) res.status(503).send('2'); // 장소 미선택
//         else{
//           if(!facility) res.status(503).send('3'); // 시설 미선택
//           else {
//             if(!date) res.status(503).send('4'); // 날짜 미선택
//             else{
//               if(!(adult&&baby)) res.status(503).send('5');
//               else {
//                 connection.query('insert into book set ?', [lecord], function(error, result){
//                   if(error){
//                     console.log("예약 추가 실패" + error); res.status(503).send('6');
//
//                   }
//                   else{
//                     console.log("에약 성공");
//                     var last = result.insertId;
//                     console.log(last);
//                     res.status(200).send({message : 'ok'});
//                   }
//                 });
//               }
//             }
//           }
//         }
//       }
//     });
// }
// else{
//   res.status(503).send('7'); // 비회원
//
// }
//
// });

module.exports = router;
